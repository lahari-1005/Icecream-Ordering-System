import datetime
import random
from bson import ObjectId
from flask import Flask, request, render_template, session, redirect
import pymongo
import os
import re

APP_ROOT = os.path.dirname(os.path.abspath(__file__))
PROFILE_PATH = APP_ROOT + "/static/icecream"
APP_ROOT = os.path.dirname(os.path.abspath(__file__))
APP_ROOT = APP_ROOT + "/static/"
my_client = pymongo.MongoClient('mongodb://localhost:27017')
my_db = my_client['IceCreamOrderingSystem']
Customer_col = my_db['Customer']
Icecream_shop_col = my_db['Icecream_shop']
delivery_boy_col = my_db['delivery_boy']
Icecream_col = my_db["Product"]
Icecream_order_col = my_db["Icecream_order"]
Icecream_order_list_col = my_db["Icecream_order_list"]
Place_order_with_payment_col = my_db["Place_order_with_payment"]
review_col = my_db["Review"]
admin_col = my_db["Admin"]
STATUS = {
    "CART": "Cart",
    "ORDERED": "Ordered",
    "PREPARING": "Preparing",
    "PREPARED": "Prepared",
    "DISPATCHED": "Dispatched",
    "PICKED_UP_BY_DELIVERY_BOY": "Picked Up By Delivery Boy",
    "DELIVERED": "Delivered",
    "CANCELLED": "Cancelled",
    "NEW": "New"
}

ICE_CREAM_TYPES = ["Scoop", "Package", "Topping"]

app = Flask(__name__)
app.secret_key = "Icecream"
count = admin_col.count_documents({})
if count == 0:
    query = {"email": "admin@gmail.com", "password": "admin"}
    admin_col.insert_one(query)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/Icecream_Shop_reg")
def Icecream_Shop_reg():
    return render_template("Icecream_Shop_reg.html")


@app.route("/Icecream_Shop_reg1", methods=["post"])
def Icecream_Shop_reg1():
    name = request.form.get("name")
    email = request.form.get("email")
    phone = request.form.get("phone")
    password = request.form.get("password")
    address = request.form.get("address")
    status = "unverified"
    query = {"$or": [{"email": email}, {"phone": phone}]}
    count = Icecream_shop_col.count_documents(query)
    if count > 0:
        return render_template("Mmsg.html", message="Duplicate Value Enter", color="text-danger")
    else:
        query2 = {"name": name, "email": email, "phone": phone, "password": password, 'address': address,
                  'status': status}
        Icecream_shop_col.insert_one(query2)
        return render_template("Mmsg.html", message="Register Added Successfully", color="text-success")


@app.route("/Icecream_Shop_login")
def Icecream_Shop_login():
    return render_template("Icecream_Shop_login.html")


@app.route("/admin_login")
def admin_login():
    return render_template("admin_login.html")


@app.route("/admin_login1", methods=['post'])
def admin_login1():
    email = request.form.get("email")
    password = request.form.get("password")
    query = {"email": email, "password": password}
    print(query)
    count = admin_col.count_documents(query)
    if count > 0:
        admin = admin_col.find_one(query)
        session["admin_id"] = str(admin['_id'])
        session['role'] = 'admin'
        return redirect("/admin_home")
    else:
        return render_template("Mhead.html", message="Invalid login details")


@app.route("/Icecream_Shop_login1", methods=['post'])
def Icecream_Shop_login1():
    email = request.form.get("email")
    password = request.form.get("password")
    query = {"email": email, "password": password}
    count = Icecream_shop_col.count_documents(query)
    if count > 0:
        Icecream_shop = Icecream_shop_col.find_one(query)
        if Icecream_shop['status'] == 'verified':
            session['Icecream_shop_id'] = str(Icecream_shop['_id'])
            session['role'] = 'Icecream_shop'
            return redirect("/icecream_home")
        else:
            return render_template("Mmsg.html", message="You Account is not Verified", color="text-danger")
    else:
        return render_template("Mmsg.html", message="Invalid Login", color="text-danger")


@app.route("/verify_Icecreamshop")
def verify_Icecreamshop():
    Icecream_shop_id = request.args.get("Icecream_shop_id")
    query1 = {"_id": ObjectId(Icecream_shop_id)}
    query2 = {"$set": {"status": "verified"}}
    Icecream_shop_col.update_one(query1, query2)
    return redirect("/icecream_shop")


@app.route("/icecream_shop")
def icecream_shop():
    Icecreams = Icecream_shop_col.find({})
    Icecreams = list(Icecreams)
    print(Icecreams)
    return render_template("icecream_shop.html", Icecreams=Icecreams)


@app.route("/icecream_home")
def icecream_home():
    return render_template("icecream_home.html")


@app.route("/logout")
def logout():
    session.clear()
    return render_template("index.html")


@app.route("/Email_verification")
def Email_verification():
    return render_template("Email_verification.html")


@app.route("/Email_verification1", methods=['post'])
def Email_verification1():
    email = request.form.get("email")
    OTP = random.randint(1000, 10000)
    print(OTP)
    #send_email("Login Verification is Successfully", "Please Use This Email" + str(OTP) + "to access your account",email)
    return render_template("Email_verification1.html", email=email, OTP=OTP)


@app.route("/Email_verification2", methods=['post'])
def Email_verification2():
    email = request.form.get("email")
    print(email)
    OTP = request.form.get("OTP")
    email_otp = request.form.get("email_otp")
    query = {"email": email}
    if OTP == email_otp:
        Customer = Customer_col.find_one(query)
        if Customer == None:
            return render_template("Customer_register.html", email=email)
        else:
            query = {"email": email}
            Customer = Customer_col.find_one(query)
            session['Customer_id'] = str(Customer['_id'])
            session['role'] = 'Customer'
            return redirect("/Customer_home")
    else:
        return render_template("Mmsg.html", message="Invalid OTP", color="text-danger")


@app.route("/admin_home")
def admin_home():
    return render_template("admin_home.html")


@app.route("/Customer_register")
def Customer_register():
    return render_template("Customer_register.html")


@app.route("/Customer_register1", methods=["post"])
def Customer_register1():
    name = request.form.get("name")
    email = request.form.get("email")
    phone = request.form.get("phone")
    password = request.form.get("password")
    gender = request.form.get("gender")
    address = request.form.get("address")
    query = {"$or": [{"email": email}, {"phone": phone}]}
    count = Customer_col.count_documents(query)
    if count > 0:
        return render_template("Mmsg.html", message="Duplicate Value Enter", color="text-danger")
    else:
        query2 = {"name": name, "email": email, "phone": phone, "password": password,
                  "gender": gender, "address": address}
        Customer_col.insert_one(query2)
        return render_template("Mmsg.html", message="Register Added Successfully", color="text-success")


@app.route("/customer_login")
def customer_login():
    return render_template("customer_login.html")


@app.route("/customer_login1", methods=['post'])
def customer_login1():
    email = request.form.get("email")
    password = request.form.get("password")
    query = {"email": email, "password": password}
    count = Customer_col.count_documents(query)
    if count > 0:
        Customer = Customer_col.find_one(query)
        session['Customer_id'] = str(Customer['_id'])
        session['role'] = 'Customer'
        return redirect("/Customer_home")
    else:
        return render_template("Mmsg.html", message="Invalid Login", color="text-danger")


@app.route("/Customer_home")
def Customer_home():
    return render_template("Customer_home.html")


@app.route("/Add_delivery_boy")
def Add_delivery_boy():
    return render_template("Add_delivery_boy.html")


@app.route("/update_password")
def update_password():
    return render_template("update_password.html")


@app.route("/update_password1", methods=['post'])
def update_password1():
    email = request.form.get("email")
    update_password = request.form.get("update_password")
    query = {"email": email}
    delivery = delivery_boy_col.find_one(query)
    print(delivery['status'])
    if delivery['status'] == "password updated":
        return render_template("Mmsg.html", message="You Already updated")
    status = "password updated"
    query3 = {"$set": {"status": status}}
    query2 = {"$set": {"password": update_password}}
    delivery_boy_col.update_one(query, query2)
    delivery_boy_col.update_one(query, query3)
    return render_template("Mmsg.html", message="Updated Successfully")


@app.route("/Add_delivery_boy1", methods=['post'])
def Add_delivery_boy1():
    icecream_shop_id = session['Icecream_shop_id']
    name = request.form.get("name")
    email = request.form.get("email")
    phone = request.form.get("phone")
    password = request.form.get("password")
    gender = request.form.get("gender")
    delivery_address = request.form.get("delivery_address")
    status = 'update password'
    query = {"name": name, "email": email, "phone": phone, "password": password, 'status': status, 'gender': gender,
             "delivery_address": delivery_address, "icecream_shop_id": ObjectId(icecream_shop_id)}
    delivery_boy_col.insert_one(query)
    return render_template("Amsg.html", message="Delivery Boy Added Successfully", color="text-success")


@app.route("/View_delivery_boy")
def View_delivery_boy():
    icecream_shop_id = session['Icecream_shop_id']
    query = {"icecream_shop_id": ObjectId(icecream_shop_id)}
    delivery_boy = delivery_boy_col.find(query)
    delivery_boys = list(delivery_boy)
    return render_template("View_delivery_boy.html", delivery_boys=delivery_boys)


@app.route("/Delivery_boy_login")
def Delivery_boy_login():
    return render_template("Delivery_boy_login.html")


@app.route("/Delivery_boy_login1", methods=['post'])
def Delivery_boy_login1():
    email = request.form.get("email")
    password = request.form.get("password")
    query = {"email": email, "password": password}
    count = delivery_boy_col.count_documents(query)
    if count > 0:
        delivery_boy = delivery_boy_col.find_one(query)
        session['delivery_boy_id'] = str(delivery_boy['_id'])
        session['role'] = 'delivery_boy'
        return redirect("/Delivery_boy_home")
    else:
        return render_template("Mmsg.html", message="Invalid Login", color="text-danger")


@app.route("/Delivery_boy_home")
def Delivery_boy_home():
    return render_template("Delivery_boy_home.html")


@app.route("/Add_icecream")
def Add_icecream():
    Icecream_shop_id = session['Icecream_shop_id']
    query = {"Icecream_shop_id": ObjectId(Icecream_shop_id)}
    icecreams = Icecream_col.find(query)
    icecreams = list(icecreams)
    return render_template("Add_icecream.html", icecreams=icecreams,
                           get_icecream_shop_by_icecream_shop_id=get_icecream_shop_by_icecream_shop_id,
                           get_icecream_rating_by_icecream_id=get_icecream_rating_by_icecream_id, ICE_CREAM_TYPES=ICE_CREAM_TYPES)


def get_icecream_rating_by_icecream_id(icecream_id):
    query = {'Icecream_id': ObjectId(icecream_id)}
    count = review_col.count_documents(query)
    if count == 0:
        return 'No Rating'
    reviews = review_col.find(query)
    reviews = list(reviews)
    print(reviews)
    avg_rating = 0
    count = 0
    for review in reviews:
        count += 1
        avg_rating = int(review['rating']) + avg_rating
        print(count)
    return round((avg_rating) / count)


@app.route("/Add_icecream1", methods=["post"])
def Add_icecream1():
    name = request.form.get("name")
    type = request.form.get("type")
    flavour = request.form.get("flavour")
    quantity = request.form.get("quantity")
    price = request.form.get("price")
    Icecream_shop_id = session['Icecream_shop_id']
    picture = request.files.get('picture')
    path = PROFILE_PATH + "/" + picture.filename
    picture.save(path)
    query2 = {"name": name, "type": type, "flavour": flavour, "quantity": quantity, "price": price,
              "picture": picture.filename,
              "Icecream_shop_id": ObjectId(Icecream_shop_id)}
    print(query2)
    Icecream_col.insert_one(query2)
    return redirect("/Add_icecream")


def get_icecream_shop_by_icecream_shop_id(Icecream_shop_id):
    query = {"_id": ObjectId(Icecream_shop_id)}
    Icecream_shop = Icecream_shop_col.find_one(query)
    return Icecream_shop


@app.route("/view_icecreams")
def view_icecreams(icecreams2=None):
    Icecream_shops = Icecream_shop_col.find({})
    Icecream_shops = list(Icecream_shops)

    Icecream_shop_id = request.args.get("Icecream_shop_id")
    name = request.args.get("name")
    if Icecream_shop_id == None:
        Icecream_shop_id = ""
    if name == None:
        name = ""
    name2 = re.compile(".*" + str(name) + ".*", re.IGNORECASE)

    if Icecream_shop_id == "":
        query = {"name": name2}
    else:
        query = {"Icecream_shop_id": ObjectId(Icecream_shop_id), "name": name2}
    icecreams = Icecream_col.find(query)
    icecreams = list(icecreams)
    return render_template("view_icecreams.html", Icecream_shops=Icecream_shops, icecreams=icecreams,
                           icecreams2=icecreams2,
                           get_icecream_shop_by_icecream_shop_id=get_icecream_shop_by_icecream_shop_id,
                           Icecream_shop_id=Icecream_shop_id, name=name, str=str, int=int)


@app.route("/addtocart")
def addtocart():
    Icecream_id = request.args.get("Icecream_id")
    quantity = request.args.get("quantity")
    Customer_id = session['Customer_id']
    query = {"_id": ObjectId(Icecream_id)}
    Icecream = Icecream_col.find_one(query)
    Icecream_shop_id = Icecream['Icecream_shop_id']
    date = datetime.datetime.now()
    query = {"Customer_id": ObjectId(Customer_id), "Icecream_shop_id": ObjectId(Icecream_shop_id),
             "status": STATUS['CART']}
    count = Icecream_order_col.count_documents(query)
    if count == 0:
        query = {"Customer_id": ObjectId(Customer_id), "Icecream_shop_id": ObjectId(Icecream_shop_id), "date": date,
                 "status": STATUS['CART']}
        result = Icecream_order_col.insert_one(query)
        Icecream_order_id = result.inserted_id
    else:
        Icecream_order = Icecream_order_col.find_one(query)
        Icecream_order_id = Icecream_order['_id']

    query2 = {"Icecream_order_id": Icecream_order_id, "Icecream_id": ObjectId(Icecream_id)}
    count1 = Icecream_order_list_col.count_documents(query2)
    query3 = {"Icecream_id": ObjectId(Icecream_id), "Icecream_order_id": ObjectId(Icecream_order_id),
              "quantity": quantity}
    if count1 == 0:
        query3 = {"Icecream_id": ObjectId(Icecream_id), "Icecream_order_id": ObjectId(Icecream_order_id),
                  "quantity": quantity}
        Icecream_order_list_col.insert_one(query3)
        return render_template("msg.html", message="Icecream added to cart")
    else:
        icecream = Icecream_order_list_col.find_one(query2)
        new_quantity = int(icecream['quantity']) + int(quantity)
        query1 = {"$set": {"quantity": new_quantity}}
        print(query1)
        Icecream_order_list_col.update_one(query2, query1)
        return render_template("msg.html", message="Item updated to cart")

    return render_template("msg.html", message="Icecream added to cart")


@app.route("/cart")
def cart():
    print(session['role'])
    type = request.args.get('type')
    query = {"aaaa": "aaaa"}
    if session['role'] == 'Customer':
        Customer_id = session['Customer_id']
        if type == 'cart':
            query = {"Customer_id": ObjectId(Customer_id), "status": STATUS['CART']}
        elif type == 'ordered':
            query = {"$or": [{"Customer_id": ObjectId(Customer_id), "status": STATUS['ORDERED']},
                             {"Customer_id": ObjectId(Customer_id), "status": STATUS['PREPARING']},
                             {"Customer_id": ObjectId(Customer_id), "status": STATUS['PREPARED']},
                             {"Customer_id": ObjectId(Customer_id), "status": STATUS['DISPATCHED']},
                             {"Customer_id": ObjectId(Customer_id), "status": STATUS['PICKED_UP_BY_DELIVERY_BOY']}]}
        elif type == 'history':
            query = {"$or": [{"Customer_id": ObjectId(Customer_id), "status": STATUS['DELIVERED']},
                             {"Customer_id": ObjectId(Customer_id), "status": STATUS['CANCELLED']}]}

    elif session['role'] == 'Icecream_shop':
        Icecream_shop_id = session['Icecream_shop_id']
        if type == 'ordered':
            query = {"Icecream_shop_id": ObjectId(Icecream_shop_id), "status": STATUS['ORDERED']}
        elif type == 'processing':
            query = {"$or": [{"Icecream_shop_id": ObjectId(Icecream_shop_id), "status": STATUS['PREPARING']},
                             {"Icecream_shop_id": ObjectId(Icecream_shop_id), "status": STATUS['PREPARED']},
                             {"Icecream_shop_id": ObjectId(Icecream_shop_id), "status": STATUS['DISPATCHED']},
                             {"Icecream_shop_id": ObjectId(Icecream_shop_id),
                              "status": STATUS['PICKED_UP_BY_DELIVERY_BOY']}]}
        elif type == 'history':
            query = {"$or": [{"Icecream_shop_id": ObjectId(Icecream_shop_id), "status": STATUS['DELIVERED']},
                             {"Icecream_shop_id": ObjectId(Icecream_shop_id), "status": STATUS['CANCELLED']}]}
    elif session['role'] == 'delivery_boy':
        delivery_boy_id = session['delivery_boy_id']
        if type == 'processing':
            query = {"$or": [{"delivery_boy_id": ObjectId(delivery_boy_id), "status": STATUS['DISPATCHED']},
                             {"delivery_boy_id": ObjectId(delivery_boy_id),
                              "status": STATUS['PICKED_UP_BY_DELIVERY_BOY']}]}
        elif type == 'history':
            query = {"delivery_boy_id": ObjectId(delivery_boy_id), "status": STATUS['DELIVERED']}
    Icecream_order = Icecream_order_col.find(query)
    Icecream_orders = list(Icecream_order)
    Icecream_orders.reverse()
    return render_template("cart.html", Icecream_orders=Icecream_orders,str=str,
                           get_Customer_name_by_Customer_id=get_Customer_name_by_Customer_id,
                           get_Icecream_shop_by_Icecream_shop_id=get_Icecream_shop_by_Icecream_shop_id,
                           get_Icecream_order_list_by_Icecream_order_id=get_Icecream_order_list_by_Icecream_order_id,
                           get_Icecream_by_Icecream_id=get_Icecream_by_Icecream_id, int=int,
                           get_total_price_by_Icecream_order_id=get_total_price_by_Icecream_order_id, STATUS=STATUS,
                           get_delivery_boys_by_Icecream_shop_id=get_delivery_boys_by_Icecream_shop_id,
                           get_delivery_type_by_icecream_order_id=get_delivery_type_by_icecream_order_id)


def get_Customer_name_by_Customer_id(Customer_id):
    query = {"_id": ObjectId(Customer_id)}
    Customer = Customer_col.find_one(query)
    return Customer


def get_Icecream_shop_by_Icecream_shop_id(Icecream_shop_id):
    query = {"_id": ObjectId(Icecream_shop_id)}
    Icecream_shop = Icecream_shop_col.find_one(query)
    return Icecream_shop


def get_Icecream_order_list_by_Icecream_order_id(Icecream_order_id):
    query = {"Icecream_order_id": Icecream_order_id}
    Icecream_order_list = Icecream_order_list_col.find(query)
    Icecream_order_lists = list(Icecream_order_list)
    return Icecream_order_lists


def get_Icecream_by_Icecream_id(Icecream_id):
    query = {"_id": ObjectId(Icecream_id)}
    Icecream = Icecream_col.find_one(query)
    return Icecream


def get_total_price_by_Icecream_order_id(Icecream_order_id):
    query = {"Icecream_order_id": Icecream_order_id}
    Icecream_order_lists = Icecream_order_list_col.find(query)
    total_amount = 0
    for Icecream_order_list in Icecream_order_lists:
        query = {"_id": Icecream_order_list['Icecream_id']}
        Icecream = Icecream_col.find_one(query)
        sub_total = int(Icecream['price']) * int(Icecream_order_list['quantity'])
        total_amount = total_amount + sub_total
    return total_amount


@app.route("/Place_order_with_payment", methods=['post'])
def Place_order_with_payment():
    Icecream_order_id = request.form.get("Icecream_order_id")
    total_amount = request.form.get("total_amount")
    status = request.form.get("status")
    delivery_type = request.form.get("delivery_type")
    print(delivery_type)
    return render_template("Place_order_with_payment.html", Icecream_order_id=Icecream_order_id,
                           total_amount=total_amount, status=status, delivery_type=delivery_type)


@app.route("/Place_order_with_payment1", methods=['post'])
def Place_order_with_payment1():
    amount = request.form.get("amount")
    print(amount)
    delivery_type = request.form.get("delivery_type")
    Icecream_order_id = request.form.get("Icecream_Order_Id")
    status = request.form.get("status")
    Card_type = request.form.get("Card_type")
    card_number = request.form.get("card_number")
    holder_name = request.form.get("holder_name")
    CVV = request.form.get("CVV")
    expiry_date = request.form.get("expiry_date")
    query1 = {"_id": ObjectId(Icecream_order_id)}
    query2 = {"$set": {"status": STATUS['ORDERED'], "delivery_type": delivery_type}}
    Icecream_order_col.update_one(query1, query2)
    Customer_id = session['Customer_id']
    Place_order_with_payment = {"Card_type": Card_type, "card_number": card_number, "holder_name": holder_name,
                                "expiry_date": expiry_date, 'delivery_type': delivery_type,'amount':amount,
                                "CVV": CVV, "Icecream_order_id":ObjectId( Icecream_order_id), "Customer_id":ObjectId(Customer_id),
                                "status": STATUS['ORDERED']}
    Place_order_with_payment_col.insert_one(Place_order_with_payment)
    query = {"Icecream_order_id": ObjectId(Icecream_order_id)}
    Icecream_items = Icecream_order_list_col.find(query)
    for Icecream_item in Icecream_items:
        query = {"_id": Icecream_item['Icecream_id']}
        icecream = Icecream_col.find_one(query)
        query2 = {"$set": {"quantity": int(icecream['quantity']) - int(Icecream_item['quantity'])}}
        Icecream_col.update_one(query, query2)

    return render_template("msg.html", message="Order Placed Successfully",
                           Place_order_with_payment=Place_order_with_payment)


def get_delivery_type_by_icecream_order_id(Icecream_order_id):
    query = {'Icecream_order_id': ObjectId(Icecream_order_id)}
    delivery = Place_order_with_payment_col.find_one(query)
    return delivery['delivery_type']


@app.route("/set_status", methods=['post'])
def set_status():
    Icecream_order_id = request.form.get('Icecream_order_id')
    status = request.form.get('status')
    if status == STATUS['CANCELLED']:
        Icecream_order_id = request.form.get('Icecream_order_id')
        query = {"Icecream_order_id": ObjectId(Icecream_order_id)}
        Icecream_items = Icecream_order_list_col.find(query)
        for Icecream_item in Icecream_items:
            query = {"_id": Icecream_item['Icecream_id']}
            Icecream = Icecream_col.find_one(query)
            query2 = {"$set": {"quantity": int(Icecream['quantity']) + int(Icecream_item['quantity'])}}
            Icecream_col.update_one(query, query2)
    query1 = {"_id": ObjectId(Icecream_order_id)}
    query2 = {"$set": {"status": status}}
    Icecream_order_col.update_one(query1, query2)
    return render_template("msg.html", message=status,
                           get_delivery_boys_by_Icecream_shop_id=get_delivery_boys_by_Icecream_shop_id)


@app.route("/set_status2", methods=['post'])
def set_status2():
    Icecream_order_id = request.form.get('Icecream_order_id')
    delivery_boy_id = request.form.get('delivery_boy_id')
    status = request.form.get('status')
    query1 = {"_id": ObjectId(Icecream_order_id)}
    query2 = {"$set": {"status": status, "delivery_boy_id": ObjectId(delivery_boy_id)}}
    Icecream_order_col.update_one(query1, query2)
    return render_template("msg.html", message=status,
                           get_delivery_boys_by_Icecream_shop_id=get_delivery_boys_by_Icecream_shop_id)


@app.route("/remove_from_cart", methods=['post'])
def remove_from_cart():
    Icecream_order_id = request.form.get('Icecream_order_id')
    Icecream_order_list_id = request.form.get('Icecream_order_list_id')
    query = {"_id": ObjectId(Icecream_order_list_id)}
    Icecream_order_list_col.delete_one(query)
    query = {"Icecream_Order_Id": ObjectId(Icecream_order_id)}
    count = Icecream_order_list_col.count_documents(query)
    if count == 0:
        query = {"_id": ObjectId(Icecream_order_id)}
        Icecream_order_col.delete_one(query)
    return render_template("msg.html", message="Removed")


def get_delivery_boys_by_Icecream_shop_id(Icecream_shop_id):
    query = {"icecream_shop_id": Icecream_shop_id}
    delivery_boys = delivery_boy_col.find(query)
    delivery_boys = list(delivery_boys)
    return delivery_boys


@app.route("/update_quantity")
def update_quantity():
    Icecream_id = request.args.get('Icecream_id')
    quantity = request.args.get('quantity')
    query = {"_id": ObjectId(Icecream_id)}
    Icecream = Icecream_col.find_one(query)
    query2 = {"$set": {'quantity': int(Icecream['quantity']) + int(quantity)}}
    Icecream_col.update_one(query, query2)
    return redirect("/Add_icecream")


@app.route("/addrating", methods=['post'])
def addrating():
    Customer_id = request.form.get('Customer_id')
    Icecream_id = request.form.get('Icecream_id')
    query = {'Customer_id': ObjectId(Customer_id), 'Icecream_id': ObjectId(Icecream_id)}
    count = review_col.count_documents(query)
    print(query)
    print(count)
    if count > 0:
        return render_template("Cmsg.html", message="You Already Given Rating")
    return render_template("addrating.html", Customer_id=Customer_id, Icecream_id=Icecream_id)


@app.route("/ratings")
def ratings():
    Icecream_id = request.args.get('Icecream_id')
    query = {'Icecream_id': ObjectId(Icecream_id)}
    reviews = review_col.find(query)
    reviews = list(reviews)
    return render_template('reviews.html', reviews=reviews,
                           get_Customer_name_by_Customer_id=get_Customer_name_by_Customer_id, int=int)


@app.route("/give_review1", methods=['post'])
def give_review1():
    Customer_id = request.form.get('Customer_id')
    Icecream_id = request.form.get('Icecream_id')
    rating = request.form.get('rating')
    review = request.form.get('review')
    date = datetime.datetime.now()
    query = {'Customer_id': ObjectId(Customer_id), 'Icecream_id': ObjectId(Icecream_id), 'rating': rating,
             'review': review, 'date': date}
    review_col.insert_one(query)
    return render_template("Cmsg.html", message="Thanks for Your Rating")

@app.route("/add_ice_cream")
def add_ice_cream():
    return render_template("add_ice_cream.html")


@app.route("/add_ice_cream1")
def add_ice_cream1():
    type = request.args.get("type")
    if type == 'Cup' or type == 'Cone':
        query = {"type": "Scoop"}
    else:
        query = {"type": "Package"}
    icecreams = Icecream_col.find(query)
    icecreams = list(icecreams)
    query = {"type" : "Topping"}
    toppings = Icecream_col.find(query)
    toppings = list(toppings)
    print(icecreams)
    print(toppings)
    return render_template("add_ice_cream1.html",type=type, icecreams=icecreams, toppings=toppings, str=str)

@app.route("/add_to_cart", methods = ['post'])
def add_to_cart():
    data = request.get_json()
    total_scoops = data["total_scoops"]
    total_topping = data["total_topping"]
    type = data['type']
    for tp in total_topping:
        total_scoops.append(tp)
    print(total_scoops)
    initial_value = 1
    count2 = 0
    Icecream_order_id = None
    for Icecream_id in total_scoops:
        quantity = 1
        Customer_id = session['Customer_id']
        query = {"_id": ObjectId(Icecream_id)}
        Icecream = Icecream_col.find_one(query)
        Icecream_shop_id = Icecream['Icecream_shop_id']
        date = datetime.datetime.now()
        query = {"Customer_id": ObjectId(Customer_id), "Icecream_shop_id": ObjectId(Icecream_shop_id),
                 "status": STATUS['CART']}
        count = Icecream_order_col.count_documents(query)
        if count == 0:
            query = {"Customer_id": ObjectId(Customer_id), "Icecream_shop_id": ObjectId(Icecream_shop_id), "date": date,
                     "status": STATUS['CART'], "type": type, "types":[type]}
            result = Icecream_order_col.insert_one(query)
            Icecream_order_id = result.inserted_id
            count2 = count2 + 1
        else:
            Icecream_order = Icecream_order_col.find_one(query)
            Icecream_order_id = Icecream_order['_id']
            if count2 == 0:
                initial_value = len(Icecream_order["types"]) + 1
                query = {"_id": Icecream_order_id}
                query2 = {"$push": {"types": type}}
                Icecream_order_col.update_one(query, query2)
                count2 = count2 +1
        query2 = {"Icecream_order_id": Icecream_order_id, "Icecream_id": ObjectId(Icecream_id), "type2": type+str(initial_value)}
        count1 = Icecream_order_list_col.count_documents(query2)
        if count1 == 0:
            query3 = {"Icecream_id": ObjectId(Icecream_id), "Icecream_order_id": ObjectId(Icecream_order_id),
                      "quantity": quantity,"type": type, "type2": type+str(initial_value)}
            Icecream_order_list_col.insert_one(query3)
        else:
            icecream = Icecream_order_list_col.find_one(query2)
            new_quantity = int(icecream['quantity']) + int(quantity)
            query1 = {"$set": {"quantity": new_quantity}}
            print(query1)
            Icecream_order_list_col.update_one(query2, query1)
    # if Icecream_order_id != None:
    #     query = {"_id": Icecream_order_id}
    #     query2 = {"$set": {"status": STATUS["CART"]}}
    #     Icecream_order_col.update_one(query, query2)
    print(data)
    return {"message": "Order Created and Added to Cart"}
app.run(debug=True)
